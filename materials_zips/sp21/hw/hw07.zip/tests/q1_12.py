test = {
  'name': 'q1_12',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # Hint: Make sure the Area Code Visited column in your new table is the shuffled column!;
          >>> -0.75 <= one_simulated_test_stat <= 0.75
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
