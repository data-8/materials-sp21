test = {
  'name': 'q1_21',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> type(clt_applies) == bool and type(residuals_normal) == bool
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
