test = {
  'name': 'q1_1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> sum_scores(2, 3, 6, 1)
          12
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> sum_scores(-2,3,5,-10)
          -4
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
