test = {
  'name': 'q1_17',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> type(same_parameters) == bool
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
