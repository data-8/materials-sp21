test = {
  'name': 'q4_3',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> boston_under_15 >= 0 and boston_under_15 <= 100
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> manila_under_15 >= 0 and manila_under_15 <= 100
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
