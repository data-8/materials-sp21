test = {
  'name': 'q4_8',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> reject_null in make_array(True, False)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
