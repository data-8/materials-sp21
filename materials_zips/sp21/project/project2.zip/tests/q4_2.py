test = {
  'name': 'q4_2',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> summed_mn_data.num_rows 
          2
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> len(summed_mn_data.labels) == 3
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
