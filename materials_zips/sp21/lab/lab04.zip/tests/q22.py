test = {
  'name': 'q22',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> str(mark_hurd_pay_string)
          '$53.25 '
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
