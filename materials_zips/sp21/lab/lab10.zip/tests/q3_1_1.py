test = {
  'name': 'q3_1_1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> cancer
          status    | negative | positive
          cancer    | 10       | 90
          no cancer | 9702     | 198
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
